import { RouterModule, Routes } from '@angular/router';

// Components

import { PagesComponent } from './pages.component';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PartnersComponent } from './partners/partners.component';


const pagesRoutes: Routes = [
    {
        path: '',
        component: PagesComponent,
        children: [
            { path: 'home', component: HomeComponent},
            { path: 'dashboard', component: DashboardComponent},
            { path: 'partners', component: PartnersComponent},
            { path: '', redirectTo: '/partners', pathMatch: 'full'},
        ]
    }
];

export const PAGES_ROUTES = RouterModule.forChild(pagesRoutes);
